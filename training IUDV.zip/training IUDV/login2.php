
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<style>
/*
Author: Javed Ur Rehman
Website: https://www.allphptricks.com/
*/

body{
	margin:0;
	padding:0;
	font-family:sans-serif;
	background:#34495e;
}
.box{
	width:300px;
	padding:40px;
	position:absolute;
	top:50%;
	left:50%;
	transform:translate(-50%,-50%);
	background:#191919;
	text-align:center;
}
.box h1{
	color:white;
	text-transform:uppercase;
	font-weight:50%;
	}

.box input[type="text"],.box input[type="password"]{
	border:0;
	background:none;
	display:block;
	margin:20px auto;
	text-align:center;
	border:2px solid #3498db;
	padding:14px 10px;
	width:200px;
	outline:none;
	color:white;
	border-radius:24px;
	transition:0.25s;

}
	.box input[type="text"]:focus.box input[type="password"]:focus{
		width:280px;
		border-color:#2ecc71;
	}
	p{
		color:white;
	}
		
</style>
</head>
<body>
<?php
	require('db.php');
	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `new_user` WHERE username='$username' and password='".md5($password)."'";
		$result = mysqli_query($con,$query) or die(mysqli_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: index.php"); // Redirect user to index.php
            }else{
				echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
?>
<div class="form">
<form action="" method="post" name="login" class="box">
<h1>Log In</h1>
<input type="text" name="username" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<input name="submit" type="submit" value="Login" />
<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
</form>


<br /><br/>
</div>
<?php } ?>


</body>
</html>
