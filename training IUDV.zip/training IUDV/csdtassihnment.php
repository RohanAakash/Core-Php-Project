<html>
<head>
<title>
ASSIGHNMENT 1
</title>
</head>
<body bgcolor="powderblue">
<table width="1200px" border="2px">
<tr>
<td colspan="1" width="300px">
<img src="csdtlogo.jfif" width="300px" height="100px"/>
</td>
<td colspan="4"><h1 align="center" style="color:red;background-color:lemonchiffon;">CSDT IT SOLUTION</h1></td>
</tr>
<tr>
<td colspan="1" width="300px"><a href="csdthome.html"><b>Home</b></a></td>
<td colspan="1"width="300px"><a href="csdtabout.html"><b>About Us</b></a></td>
<td colspan="1"width="300px"><a href="csdtcontact.html"><b>Contact</b></a></td>
<td colspan="1" width="300px"><a href="login2.php"><b>Login</b></a></td>
</tr>
<tr>
<td colspan="4">
<img src="csdtimg1.jfif" width="1200px" height="250px"/>
</td>
</tr>
<tr style="background-color:grey;">
<td colspan="1"><h2>Services</h2>
<ul>
<li>web Development</li>
<li>Android app Development</li>
<li>Software Development</li>
</ul>
</td>
<td colspan="2" style="background-color:brown;">   </td>
<td colspan="3"><h2 style="color:brown">News</h2>
<ol>
<li>ranked 1st in patna</li>
<li>Best Training Centre</li>
<li>Excellency award 2019 </li>
</ol>
</td>
</tr>
<tr>
<td colspan="4"><h1>DEVELOPED BY:ROHAN</h1> </td>
</tr>
</table>
</body>
</html>
